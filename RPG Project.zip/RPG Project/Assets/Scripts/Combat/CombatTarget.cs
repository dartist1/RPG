using UnityEngine;

namespace RPG.Combat
{
    public class CombatTarget : MonoBehaviour  
    {
    
    }
}