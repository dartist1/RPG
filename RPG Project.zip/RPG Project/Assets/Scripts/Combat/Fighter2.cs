using UnityEngine;

namespace RPG.Combat
{
    public class Fighter2 : MonoBehaviour 
    {
        public void Attack(CombatTarget target)
        {
            print("Get clapped!");
        }
    } 
}
